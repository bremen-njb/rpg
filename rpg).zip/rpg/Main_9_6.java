package rpg;

public class Main_9_6 {
	public static void main(String[ ] args) {
		Hero h = new Hero("ミナト", 123);
		System.out.println
			("勇者" + h.getName( ) + "、HP=" + h.getHp( ));
		Hero h2 = new Hero("アサカ");
		System.out.println
			("勇者" + h2.getName( ) + "、HP=" + h2.getHp( ));
		Hero hx = new Hero( );
		System.out.println
			("勇者" + hx.getName( ) + "、HP=" + hx.getHp( ));
		hx.setName("名無しの権兵衛");
		hx.setHp(77);
		System.out.println
			("勇者" + hx.getName( ) + "、HP=" + hx.getHp( ));

		Matango m1 = new Matango( );
		m1.setHp(50);
		m1.setSuffix('A');
		Matango m2 = new Matango( );
		m2.setHp(48);
		m2.setSuffix('B');
		m1.run( );
		m2.run( );
		Matango m3 = new Matango(46, 'C');
		m3.run( );	
	}
}
