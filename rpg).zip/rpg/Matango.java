package rpg;

public class Matango {
	//フィールド
	public static final int LEVEL = 10;
	private int hp;
	private char suffix;
	//コンストラクタ
	public Matango(int hp, char suffix) {
		this.hp = hp;
		this.suffix = suffix;
	}
	public Matango( ) {		
	}
	//アクセッサ
	public int getHp( ) { return hp; }
	public void setHp(int hp) { this.hp = hp; }
	public char getSuffix( ) { return suffix; }
	public void setSuffix(char suffix) { this.suffix = suffix; }
	//メソッド
	public void run( ) {
		System.out.println
			("Matango" + suffix + "は逃亡！"
			 + "、HP=" + hp);
	}
}
