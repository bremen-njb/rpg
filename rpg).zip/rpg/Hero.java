package rpg;

public class Hero {
	//フィールド
	private String name;
	private int hp;
	private Sword sword;
	//コンストラクタ
	public Hero(String name, int hp, Sword sword) {
		this.name = name;				//引数 3個
		this.hp = hp;
		this.sword = sword;
	}
	public Hero(String name, int hp) {	//引数 2個
		this(name, hp, null);
	}
	public Hero(String name) {			//引数 1個
		this(name, 100);
	}
	public Hero( ) {					//引数 0個
		this("ダミー");
	}
	//アクセッサ
	public String getName( ) { return name; }
	public void setName(String name) { this.name = name; }
	public int getHp( ) { return hp; }
	public void setHp(int hp) { this.hp = hp; }
	public Sword getSword( ) { return sword; }
	public void setSword(Sword sword) { this.sword = sword; }
	//メソッド
	public void sleep( ) {
		hp = 100;
		System.out.println("<sleep>" + name + "は、眠って回復！ HP=" + hp);
	}
	public void sit(int sec) {
		hp += sec;
		System.out.println
			("<sit>  " + name + "は、" + sec + "秒座って回復！ HP=" + hp);
	}
	public void slip( ) {
		hp -= 5;
		System.out.println("<slip> " + name + "は、転んだ！ HP=" + hp);
	}
	public void run( ) {
		System.out.println("<run>  GAMEOVER  " + name + "の最終HP=" + hp);
	}
	public void display( ) {
		System.out.print
			("勇者=" + name + "、HP=" + hp);
		if (sword != null) {
			System.out.println
				("、武器=" + sword.getName( ) +
				 "、威力=" + sword.getDamage( ));
		} else {
			System.out.println( );
		}
	}
}
