package rpg;
import java.util.*;
public class Cleric {
	//フィールド
	final int MAX_HP = 50;
	final int MAX_MP = 10;
	String name;
	int hp = MAX_HP;
	int mp = MAX_MP;
	Random random = new Random( );
	//メソッド
	public void selfAid( ) {
		System.out.print(name + "は唱えた!");
		hp = MAX_HP;
		mp -= 5;
		System.out.println("HPが最大まで回復!");
	}
	public int pray(int sec) {
		int recovery = sec + random.nextInt(3);
		int oldMp = mp;
		mp = Math.min(oldMp + recovery, MAX_MP);
		return  mp - oldMp;
	}
}	
	