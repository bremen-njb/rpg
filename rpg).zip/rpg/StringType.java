package rpg;

public class StringType {
	public static void main(String[ ] args) {
		String s0, s1, s2, s3;
		s0 = "abcde";
		s1 = s0 + "123";
		s2 = s0 + "123";
		s3 = "abcde";
		
		if (s1 == s2) {
			System.out.println("s1 == s2");
		} else {
			System.out.println("s1 != s2");			
		}
		if (s1.equals(s2)) {
			System.out.println("s1 equals s2");
		} else {
			System.out.println("s1 not equals s2");			
		}
		if (s0 == s3) {
			System.out.println("s0 == s3");
		} else {
			System.out.println("s0 != s3");			
		}
		if (s0.equals(s3)) {
			System.out.println("s0 equals s3");
		} else {
			System.out.println("s0 not equals s3");			
		}		
	}
}
