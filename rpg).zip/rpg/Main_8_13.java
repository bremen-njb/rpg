package rpg;

public class Main_8_13 {
	public static void main(String[ ] args) {
		Hero h = new Hero( );
		h.name = "ミナト";
		h.hp = 100;
		System.out.println("<main> 勇者" + h.name + "、HP=" + h.hp);
		h.hp = 50;
		System.out.println("<main> 勇者" + h.name + "、HP=" + h.hp);
		h.sleep( );
		h.sit(5);
		h.slip( );
		h.sit(25);
		h.run( );
	}
}
